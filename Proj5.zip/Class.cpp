//File:    Class.cpp
//Project: Project 5, Fall 2019
//Author:  Gabe Maturo
//Date:    11/26/2019
//Section: 11
//E-mail:  ak36939@umbc.edu
//Description: This is the .cpp for "Class.h" that implements the getter,
//             setter, helper, and constructor functions. This file creates
//             a "Class"

#include "Class.h"

//Default Constructor
Class::Class(){}

//Constructor
Class::Class(string name, int section){
  m_name = name;
  m_section = section;
}

//Destructor
Class::~Class(){

  //empties out the dynamically allocated students from roster and the waitlist
  for(int i = 0; i < m_roster.Size(); i++){
    delete m_roster[i];
  }
  for(int i = 0; i < m_waitlist.Size(); i++){
    delete m_waitlist[i];
  }
}

//Getters and Setters
string Class::GetName(){
  return m_name;
}

void Class::SetName(string name){
  m_name = name;
}

int Class::GetSection(){
  return m_section;
}

void Class::SetSection(int section){
  m_section = section;
}

void Class::DisplayStudents(){

  //Goes through each item in the lists and prints them out
  //with their cout statement
  cout << "Enrolled (" << m_roster.Size() << ")" << endl;
  for(int i = 0; i < m_roster.Size(); i++){
    cout << *m_roster[i] << endl;
  }
  cout << "Waitlisted (" << m_waitlist.Size() << ")" << endl;
  for(int i = 0; i < m_waitlist.Size(); i++){
    cout << *m_waitlist[i] << endl;
  }
}

bool Class::AddStudent(Student* student){

  //check to see if roster and waitlist are full. If they are, return false
  if(IsRosterFull() == true){
    if(IsWaitlistFull() == true){
      return false;
    }
    //if just the roster is full, add the student to the waitlist
    m_waitlist.Enqueue(student);
  }
  else
    //if neither is full, add the student to the roster
    m_roster.Enqueue(student);

  return true;

}

void Class::SortStudents(){

  m_roster.Sort();
  m_waitlist.Sort();
  
}

void Class::TransferWaitToRoster(Class& destination){

  //add all of the students from the waitlist to the roster
  for(int i = 0; i < m_waitlist.Size(); i++){
    destination.AddStudent(m_waitlist[i]);
  }
  //clear the waitlist
  m_waitlist.ClearData();
}

bool Class::IsRosterFull(){

  //checks if the roster size is equal to its maximum size
  if(m_roster.Size() >= ROSTER_MAX)
    return true;
  else
    return false;

}

bool Class::IsWaitlistFull(){

  //checks if the waitlist size is equal to its maximum size
  if(m_waitlist.Size() >= WAIT_MAX)
    return true;
  else
    return false;

}

bool Class::SearchClass(string item){

  //looks through each item in the roster and the waitlist and if any
  //of the first or last names are equal to the search, it prints out
  //the course that they can be found in and returns true
  for(int i = 0; i < m_roster.Size(); i++){
    if(m_roster[i]->GetFName() == item || m_roster[i]->GetLName() == item){
      
      cout << "Course: " << GetName() << " Section: " << GetSection() << endl;
      return true;
    }
   }
   for(int i = 0; i < m_waitlist.Size(); i++){
     if(m_waitlist[i]->GetFName() == item || m_waitlist[i]->GetLName() == item){
       cout << "Course: " << GetName() << " Section: " << GetSection() << endl;
       return true;
     }
   }
   return false;
}

//Overloaded << Operator for Class cout statements
ostream& operator<<(ostream& output, Class& class1){

  output << "Course: " << class1.m_name << " Section: " << class1.m_section << endl;
  return output;

}
