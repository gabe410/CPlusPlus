//File:    Scheduler.cpp
//Project: Project 5, Fall 2019
//Author:  Gabe Maturo
//Date:    11/26/2019
//Section: 11
//E-mail:  ak36939@umbc.edu
//Description: This is the .cpp for "Scheduler.h" that uses functions from
//             the other classes and this class to basically run the simulator
#include "Scheduler.h"

//Default Constructor
Scheduler::Scheduler(){}

//Constructor
Scheduler::Scheduler(string fileName){

  m_fileName = fileName;
  m_name = "Fall 2019";
  
}

//Destructor
Scheduler::~Scheduler(){

  //delete the dynamically allocated vector holding the classes
  for(int i = 0; i < (int)m_classes.size(); i++){
    delete m_classes.at(i);
  }
}

void Scheduler::LoadFile(){

  string lName;
  string fName;
  string id;
  string className;
  Student* newStudent;
  ifstream inputStream;
  inputStream.open(m_fileName);
  //read in the information from each line in the .txt file
  while(getline(inputStream, fName, ',') &&
	getline(inputStream, lName, ',') &&
	getline(inputStream, id, ',') &&
	getline(inputStream, className)){
    //make a new student
    newStudent = new Student(fName, lName, stoi(id));
    //add the new student to the class
    AddStudent(newStudent, className);
  }
  inputStream.close();
}

void Scheduler::MainMenu(){

  int choice = 0;
  //runs until the user selects 5/quit
  while(choice != 5){
    cout << "1. Display All Courses" << endl;
    cout << "2. Display Specific Course" << endl;
    cout << "3. Search for Specific Student" << endl;
    cout << "4. Sort Roster" << endl;
    cout << "5. Quit" << endl;
    cin >> choice;
    //input validation
    while(choice > 5 || choice < 1){
      cout << "Must pick an option between 1 and 5." << endl;
      cout << "1. Display All Courses" << endl;
      cout << "2. Display Specific Course" << endl;
      cout << "3. Search for Specific Student" << endl;
      cout << "4. Sort Roster" << endl;
      cout << "5. Quit" << endl;
      cin >> choice;
    }
    //these if statements call the corresponding function that is used
    //based off what action the user wants to execute
    if(choice == 1)
      DisplayCourses();
    if(choice == 2)
      DisplaySpecific();
    if(choice == 3)
      SearchStudent();
    if(choice == 4)
      SortRoster();
  }
}

void Scheduler::DisplayCourses(){
 
  //display each classes' cout statement
  for(int i = 0; i < (int)m_classes.size(); i++){
    cout << *m_classes.at(i) << endl;
  }
}

void Scheduler::DisplaySpecific(){

  int courseChoice;
  cout << "Which course would you like to display?" << endl;
  for(int i = 0; i < (int)m_classes.size(); i++){
    cout << i + 1 << "." << *m_classes.at(i);
  }
  cin >> courseChoice;
  //input validation
  while(courseChoice > (int)m_classes.size() || courseChoice < 1){
    cout << "Must choose an option between 1 and " << (int)m_classes.size() << endl;
    for(int i = 0; i < (int)m_classes.size(); i++){
      cout << i + 1 << "." << *m_classes.at(i);
    }
    cin >> courseChoice;
  }
  cout << "Displaying Student" << endl;
  cout << *m_classes.at(courseChoice - 1) << endl;
  //for the selected class, print out the students in the class
  m_classes.at(courseChoice - 1)->DisplayStudents();
}

void Scheduler::SearchStudent(){

  string search;
  cout << "What name do you want to search for?" << endl;
  cin >> search;
  cout << "Items with " << search << " in them: " << endl;
  //this for loop looks through all of the classes for what is being searched
  for(int i = 0; i < (int)m_classes.size(); i++){
    m_classes.at(i)->SearchClass(search);
  }
}

void Scheduler::SortRoster(){

  //sorts the students in each class
  for(int i = 0; i < (int)m_classes.size(); i++){
    m_classes.at(i)->SortStudents();
  }
}

void Scheduler::Start(){

  cout << "Welcome to UMBC Scheduler" << endl;
  LoadFile();
  MainMenu();

}

int Scheduler::FindClass(string class1){

  //if there are no classes yet, return -1
  if(m_classes.size() == 0){
    return -1;
  }
  else {
    for(int i = (int)m_classes.size() - 1; i >= 0; i--){
      //if there is an existing class in m_classes, then return the index
      //of that class
      if(m_classes.at(i)->GetName() == class1)
	return i;
    }
  }
  return -1;
}

void Scheduler::AddStudent(Student* student, string class1){

  Class* newClass;
  int currClass = FindClass(class1);
  //if the class doesn't exist, make a new class, add it to the vector of
  //classes and then add the student to that class
  if(currClass == -1){
    newClass = new Class(class1, 1);
    m_classes.push_back(newClass);
    newClass->AddStudent(student);
  }
  else {
    //if the roster and the waitlist are full, make a new section of the class
    //transfer the waitlist to the roster, and then add the student to the
    //new class
    if(m_classes.at(currClass)->AddStudent(student) == false){
      newClass = new Class(class1, m_classes.at(currClass)->GetSection() + 1);
      m_classes.push_back(newClass);
      m_classes.at(currClass)->TransferWaitToRoster(*newClass);
      newClass->AddStudent(student);
    }
  }
}
