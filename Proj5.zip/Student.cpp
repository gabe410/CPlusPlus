//File:    Student.cpp
//Project: Project 5, Fall 2019
//Author:  Gabe Maturo
//Date:    11/26/2019
//Section: 11
//E-mail:  ak36939@umbc.edu
//Description: This is the .cpp for "Student.h" that implements the getter,
//             setter, helper, and constructor functions. This file creates
//             a Student class.

#include "Student.h"

//Default Constructor
Student::Student(){}

//Constructor
Student::Student(string fName, string lName, int id){
  m_fName = fName;
  m_lName = lName;
  m_id = id;
}

//Getters
string Student::GetFName(){
  return m_fName;
}

string Student::GetLName(){
  return m_lName;
}

int Student::GetID(){
  return m_id;
}

//Setters
void Student::SetFName(string fName){
  m_fName = fName;
}

void Student::SetLName(string lName){
  m_lName = lName;
}

void Student::SetID(int id){
  m_id = id;
}

//Overloaded << Operator
ostream& operator<<(ostream& out, Student& stud){

  out << stud.m_lName << ", " << stud.m_fName << ", " << stud.m_id << endl;
  return out;

}

//Overloaded comparison Operator
bool operator<(const Student &stud1, const Student &stud2){

  //compares the students for sorting purposes
  if(stud1.m_lName < stud2.m_lName)
    return true;
  else
    return false;

}
