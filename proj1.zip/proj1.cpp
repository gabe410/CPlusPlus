//File:     proj1.cpp
//Project:  CMSC 202 Project 1, Fall 2019
//Author:   Gabe Maturo
//Date:     9/13/19
//Section:  MoWe 2:30 Lecture, 10:00 Mo Lab
//E-mail:   ak36939@umbc.edu
//Description:   This program allows the user to play the game of "Chase
//               the Rabbit." The user will play as the farmer and will
//               choose where to move so as to try and catch the rabbit.

#include <iostream>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
using namespace std;
// the max size of the gameBoard array
const int MAX_SIZE = 10;

// rabbitStart gives the rabbit a random starting position on the gameBoard, and takes in an array
char rabbitStart(char board[][MAX_SIZE]);
// farmerStart asks and validates where the user wants to start on the board, and takes in an array
char farmerStart(char board[][MAX_SIZE]);
// moveRabbit gives the rabbit a one-space random move for ech turn, takes in 2 arrays
void moveRabbit(char board[][MAX_SIZE], int winBoard[]);
// makePositive takes in an integer and makes it positive
int makePositive(int num);
// rabbitLocation takes in an array and tells the user the location of the rabbit after each move
void rabbitLocation(char board[][MAX_SIZE]);
// moveFarmer moves the farmer on the gameboard in the direction that the user chooses, takes in 2 arrays 
void moveFarmer(char board[][MAX_SIZE], int winBoard[]);
// printField takes in an array and prints the field/gameBoard properly
char printField(char board[][MAX_SIZE]);

int main() {

  // the gameboard to be used for the game
  char gameBoard[][MAX_SIZE] = {{' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '}, {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '}, {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '}, {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '}, {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '}, {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',' ', ' '}, {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '}, {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '}, {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '}, {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '}};  
  // these arrays store the x and y coordinates of the farmer and rabbit
  // so that we can check to see if the farmer has caught the rabbit
  int rabbit[2] = {};
  int farmer[2] = {};
  int gameWon = 0;
  int row;
  int column;
  int keepPlaying = 0;
  char answer;
  cout << "Welcome to Chase the Rabbit!" << endl;
  while(keepPlaying != 1){
    // starts the farmer and the rabbit and displays their starting positions
    farmerStart(gameBoard);
    rabbitStart(gameBoard);
    printField(gameBoard);
    // runs the games until the farmer has caught the rabbit
    do {
      // moves the farmer and then the rabbit, while also displaying where the rabbit is in relation to the farmer
      moveFarmer(gameBoard, farmer);
      moveRabbit(gameBoard, rabbit);
      rabbitLocation(gameBoard);
      // checks if the farmer has caught the rabbit
      if(rabbit[0] == farmer[0] && rabbit[1] == farmer[1]){
	gameWon = 1;
	gameBoard[rabbit[0]][rabbit[1]] = 'F';
      }
      printField(gameBoard);
    }
    while (gameWon != 1);
    
    cout << "Congrats, you've won!" << endl;
    cout << "Play again? (y/n)" << endl;
    cin >> answer;
    if(answer == 'n')
      keepPlaying = 1;
    for(row = 0; row < MAX_SIZE; row++){
      for(column = 0; column < MAX_SIZE; column++){
	gameBoard[row][column] = ' ';
      }
    }
    gameWon = 0;
  }
}
char rabbitStart(char board[][MAX_SIZE]) {
  int row;
  int column;
  srand(time(NULL));
  // gives the rabbit a random row and a random column from which to start
  row = rand() % MAX_SIZE;
  column = rand() % MAX_SIZE;
  // sets the starting position of the rabbit on the board
  board[row][column] = 'R';
  return 0;
}

char farmerStart(char board[][MAX_SIZE]) {
  int column;
  int row;
  cout << "Where would you like to start the farmer? " << endl;
  cout << "Enter the column(x) (0-9) " << endl;
  cin >> column;
  // validates the numbers that the user enters for the column
  while(column < 0 || column > 9){
    cout << "Enter a column between 0 and 9." << endl;
    cin >> column;
  }
  cout << "Enter the row(y) (0-9) " << endl;
  cin >> row;
  // validates the numbers that the user enters for the row
  while(row < 0 || row > 9){
    cout << "Enter a row between 0 and 9." << endl;
    cin >> row;
  }
  // sets the starting position of the farmer on the board
  board[row][column] = 'F';
  return 0;
}

void moveRabbit(char board[][MAX_SIZE], int winBoard[]) {
  int i;
  int j;
  int row;
  int column;
  int move;
  int rowMove;
  int columnMove;
  int rXcoord;
  int rYcoord;
  srand(time(NULL));
  // creates a random move in each direction (including staying still) for the rabbit
  move = rand() % 5;
  if(move == 0){
    rowMove = 0;
    columnMove = 0;
  }
  if(move == 1){
    rowMove = -1;
    columnMove = 0;
  }
  if(move == 2){
    rowMove = 0;
    columnMove = 1;
  }
  if(move == 3){
    rowMove = 1;
    columnMove = 0;
  }
  if(move == 4){
    rowMove = 0;
    columnMove = -1;
  }
  for(row = 0; row < MAX_SIZE; row++){
    for(column = 0; column < MAX_SIZE; column++){
      // stores the current position of the rabbit and replaces it with a space
      if(board[row][column] == 'R'){
	rYcoord = row;
	rXcoord = column;
	board[row][column] = ' ';
	// if the rabbit's move causes it to go out of bounds, make it stay until it gets a new move
	if(row + rowMove < 0 || row + rowMove > MAX_SIZE - 1 || column + columnMove < 0 || column + columnMove > MAX_SIZE - 1){
	  rowMove = 0;
	  columnMove = 0;
	}
      }
    }
  }
  if (rowMove == 0 && columnMove == 0)
    cout << "The rabbit nibbles on some food and does not move." << endl;
  else
    cout << "The rabbit moves to another location in search of food" << endl;
  // sets the new rabbit position on the board
  board[rYcoord + rowMove][rXcoord + columnMove] = 'R';
  // stores the new rabbit position on the win-board
  winBoard[0] = rYcoord + rowMove;
  winBoard[1] = rXcoord + columnMove;
}

int makePositive(int num){
  // makes the number positive by giving its absolute value
  num = num * -1;
  return num;
}

void rabbitLocation(char board[][MAX_SIZE]){
  int i;
  int j;
  int fRow;
  int fColumn;
  int rRow;
  int rColumn;
  int rfColumnDistance;
  int rfRowDistance;
  // gets the current farmer and rabbit location
  for(i = 0; i < MAX_SIZE; i++){
    for(j = 0; j < MAX_SIZE; j++){
      if(board[i][j] == 'F'){
	fRow = i;
	fColumn = j;
      }
      if(board[i][j] == 'R'){
	rRow = i;
	rColumn = j;
      }
    }
  }
  // these statements get whether the row or column difference between the rabbit and farmer
  // is bigger and then assesses exactly what location the rabbit is in relation to the farmer
  rfRowDistance = rRow - fRow;
  rfColumnDistance = rColumn - fColumn;
  if(rfRowDistance < 0)
    rfRowDistance = makePositive(rfRowDistance);
  if(rfColumnDistance < 0)
    rfColumnDistance = makePositive(rfColumnDistance);
  // checks to see if rabbit position is greater up and down than left to right
  if(rfRowDistance > rfColumnDistance){
    // checks if rabbit position is north or south of the farmer
    if(rRow > fRow)
      cout << "The rabbit is south of the farmer" << endl;
    else
      cout << "The rabbit is north of the farmer" << endl;
  }
  // checks to see if rabbit position is greater left to right than up and down
  if(rfColumnDistance > rfRowDistance){
    if(rColumn > fColumn)
      cout << "The rabbit is east of the farmer" << endl;
    else
      cout << "The rabbit is west of the farmer" << endl;
  }
  // does either if the rabbit is the same distance in 2 directions
  if(rfColumnDistance == rfRowDistance){
    if(rRow > fRow)
      cout << "The rabbit is south of the farmer" << endl;
    else
      cout << "The rabbit is north of the farmer" << endl;
    if(rColumn > fColumn)
      cout << "The rabbit is east of the farmer" << endl;
    else
	cout << "The rabbit is west of the farmer" << endl;
  }
}

void moveFarmer(char board[][MAX_SIZE], int winBoard[]) {
  int row;
  int column;
  int rowMove;
  int columnMove;
  int direction;
  int fXcoord;
  int fYcoord;
  cout << "What would you like to do? " << endl;
  cout << "1. Search north." << endl;
  cout << "2. Search east." << endl;
  cout << "3. Search south." << endl;
  cout << "4. Search west." << endl;
  cin >> direction;

  // validates that the user enters a valid direction
  while(direction < 1 || direction > 4){
    cout << "You must pick to move 1. north, 2. east, 3. south, or 4. west" << endl;
    cin >> direction;
  }
  // this switch statement gives the farmer the direction to move
  // depending on what the user selects
  switch (direction)
    {
    case 1:
      rowMove = -1;
      columnMove = 0;
      break;
    case 2:
      rowMove = 0;
      columnMove = 1;
      break;
    case 3:
      rowMove = 1;
      columnMove = 0;
      break;
    case 4:
      rowMove = 0;
      columnMove = -1;
      break;
  }
  // stores the current farmer location and replaces it with a space 
  for(row = 0; row < MAX_SIZE; row++){
    for(column = 0; column < MAX_SIZE; column++){
      if(board[row][column] == 'F'){
	fYcoord = row;
	fXcoord = column;
	board[row][column] = ' ';
	// makes sure that the user doesn't pick a direction that would cause the farmer to
	// move out of bounds
        if(row + rowMove < 0 || row + rowMove > MAX_SIZE - 1 || column + columnMove < 0 || column + columnMove > MAX_SIZE - 1){
          cout << "The farmer can't leave the field" << endl;
	  rowMove = 0;
	  columnMove = 0;
	}
      }
    }
  }
  // sets the new farmer location on the board and states where the farmer has moved
  board[fYcoord + rowMove][fXcoord + columnMove] = 'F';
  if(direction == 1)
    cout << "The farmer moves north" << endl;
  if(direction == 2)
    cout << "The farmer moves east" << endl;
  if(direction == 3)
    cout << "The farmer moves south" << endl;
  if(direction == 4)
    cout << "The farmer moves west" << endl;
  // stores the farmer's location on the win-board
  winBoard[0] = fYcoord + rowMove;
  winBoard[1] = fXcoord + columnMove;
}

char printField(char board[][MAX_SIZE]){
  int i;
  int j;
  for(i = 0; i < MAX_SIZE; i++){
    cout << "|";
    for(j = 0; j < MAX_SIZE; j++){
      cout << board[i][j] << "|";
      if(j == MAX_SIZE - 1)
        cout << endl;
    }
  }
  return 0;
}
