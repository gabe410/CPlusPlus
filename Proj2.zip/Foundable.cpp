//File:    Foundable.cpp
//Project: Project 2, Fall 2019
//Author:  Gabe Maturo
//Date:    10/09/2019
//Section: 11
//E-mail:  ak36939@umbc.edu
//Description: this is the .cpp for "Foundable.h" that implements the getter,
//             setter, and constructor functions
#include "Foundable.h"

//Getters

string Foundable::GetName(){
  return m_name;
}

string Foundable::GetType(){
  return m_type;
}

int Foundable::GetRarity(){
  return m_rarity;
}

int Foundable::GetToughness(){
  return m_toughness;
}

//Setters

void Foundable::SetName(string newName){
  m_name = newName;
}

void Foundable::SetType(string newType){
  m_type = newType;
}

void Foundable::SetRarity(int newRarity){
  m_rarity = newRarity;
}

void Foundable::SetToughness(int newToughness){
  m_toughness = newToughness;
}

//Foundable constructors

//Default Constructor
Foundable::Foundable(){}

Foundable::Foundable(string name, string type, int rarity, int toughness){

  m_name = name;
  m_type = type;
  m_rarity = rarity;
  m_toughness = toughness;
  
}


