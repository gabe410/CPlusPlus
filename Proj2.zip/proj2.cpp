//File:    proj2.cpp
//Project: Project 2, Fall 2019
//Author:  Gabe Maturo
//Date:    10/09/2019
//Section: 11
//E-mail:  ak36939@umbc.edu
//Description: This file runs the game of Wizards Unite through the main()
//             function

#include <iostream>
#include <ctime>
#include <cstdlib>
#include "Foundable.h"
#include "Wizard.h"
#include "Game.h"

using namespace std;

int main () {
  srand(time(NULL));
  Game();
  return 0;
}
