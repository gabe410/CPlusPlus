//File:    Wizard.cpp
//Project: Project 2, Fall 2019
//Author:  Gabe Maturo
//Date:    10/09/2019
//Section: 11
//E-mail:  ak36939@umbc.edu
//Description: this is the .cpp for "Wizard.h" that implements the getter,
//             setter, helper, and constructor functions

#include "Wizard.h"

//Getters

string Wizard::GetName(){
  return m_name;
}

int Wizard::GetToughness(){
  return m_toughness;
}

int Wizard::GetLevel(){
  return m_level;
}

int Wizard::GetWins(){
  return m_wins;
}

int Wizard::GetLosses(){
  return m_losses;
}

//Setters

void Wizard::SetName(string name){
  m_name = name;
}

void Wizard::SetToughness(int toughness){
  m_toughness = toughness;
}

//Functions

void Wizard::InsertFoundable(Foundable newFoundable){

  //inserts the foundable at the next spot in the array that
  //stores the foundables that have been defeated
  m_foundables[m_level - 1] = newFoundable;

}

bool Wizard::CheckFoundable(Foundable newFoundable){

  //this for loop checks every index to see if any of the foundables
  //are the same in the wizard's foundables array and the array that holds
  //all of the foundables
  int i;
  for(i=0; i < m_level; i++){
    //if the foundables are the same, return true, otherwise return false
    if(m_foundables[i].GetName() == newFoundable.GetName())
      return true;
  }
  return false;
}

bool Wizard::AttackFoundable(Foundable enemy){

  //this if else statement checks to see if the enemy foundable has a higher
  //toughness than the wizard, and if it does, the function returns false
  //otherwise it will return true
  if (enemy.GetToughness() <  m_toughness){
    IncreaseLevel();
    m_wins ++;
    cout << "You defeated " << enemy.GetName() << "!" << endl;
    return true;
  }
  else{
    m_losses ++;
    cout << enemy.GetName()  <<" has defeated you! " << endl;
    return false;
  }
}

void Wizard::PrintMyFoundables(){
  int i;
  cout << m_foundables[0].GetName() << endl;
  //this for loop gets each part of the foundable and prints it out in the correct format
  for(i = 1; i < m_level; i++){
    cout << i  << "." << m_foundables[i].GetName() << "| " << m_foundables[i].GetType() << "| " << m_foundables[i].GetRarity() << "| " << m_foundables[i].GetToughness() << endl;
  }
  if(m_level == 1)
    cout << "You have not defeated any Foundables yet." << endl;
}

void Wizard::IncreaseLevel(){
  m_level++;
  //randomizes the toughness that the wizard increases by each time it wins
  m_toughness = m_toughness + (rand() % LEVEL_TOUGH_INCREASE + 1);
}

//Wizard Constructors

//Default constructor
Wizard::Wizard(){
  m_name = "Default";
  m_toughness = 1;
  m_level = 1;
  m_losses = 0;
  m_wins = 0;

}

Wizard::Wizard(string name){
  m_name = name;
  m_toughness = 1;
  m_level = 1;
  m_losses = 0;
  m_wins = 0;
}
