//File:    Game.cpp
//Project: Project 2, Fall 2019
//Author:  Gabe Maturo
//Date:    10/09/2019
//Section: 11
//E-mail:  ak36939@umbc.edu
//Description: This is the .cpp for "Game.h" that implements the getter,
//             setter, helper, and constructor functions. This file essentially
//             runs the game of Wizards Unite.

#include "Game.h"
//Functions

void Game::GetWizardName(){

  string wName;
  cout << "What is your wizard's name? " << endl;
  //allows there to be a space in the wizard's name
  getline(cin, wName);
  m_wizard.SetName(wName);
  //sets the starting toughness to a random number between 150 and 300
  m_wizard.SetToughness((rand() % (MAX_START_TOUGH + 1 - MIN_START_TOUGH)) + MIN_START_TOUGH);

}

void Game::MainMenu(){

  int choice;
  //while the wizard has not found the foundables and the user has not quit, run the game
  while(m_wizard.GetLevel() != 192 && choice != 5){
    cout << " " << endl;
    cout << "What would you like to do? " << endl;
    cout << "1. Wizard Information " << endl;
    cout << "2. List My Foundables " << endl;
    cout << "3. List All Foundables " << endl;
    cout << "4. Attack Foundable " << endl;
    cout << "5. Quit " << endl;
    cin >> choice;
    while(choice > 5 || choice < 1){
      cout << " " << endl;
      cout << "Must choose an option (1-5)" << endl;
      cout << "What would you like to do? " << endl;
      cout << "1. Wizard Information " << endl;
      cout << "2. List My Foundables " << endl;
      cout << "3. List All Foundables " << endl;
      cout << "4. Attack Foundable " << endl;
      cout << "5. Quit " << endl;
      cin >> choice;
    }
    //runs the correct function based off the choice the user makes
    if(choice == 1)
      WizardStat();
    if(choice == 2)
      PrintMyFoundables();
    if(choice == 3)
      PrintFoundables();
    if(choice == 4)
      AttackFoundable();
  }
  if(m_wizard.GetLevel() == 192)
    cout << "Congratulations, you have defeated all of the foundables!" << endl;
}

int Game::LoadFoundables(){

  int i = 0;
  string name;
  string type;
  string rarity;
  string toughness;
  ifstream inputStream;
  inputStream.open(FILE_NAME);

  //reads in the file for each part of each foundable
  //and adds it to an array storing all of the foundables
  for(i = 0; i < NUM_FOUNDABLE; i++){
    getline(inputStream, name, ',');
    getline(inputStream, type, ',');
    getline(inputStream, rarity, ',');
    getline(inputStream, toughness, '\n');
    m_allFoundables[i] = Foundable(name, type, stoi(rarity), stoi(toughness));
  }
  inputStream.close();
  return 0;
}

void Game::PrintFoundables(){

  int i;
  //prints out each part of the foundables that are stored in the array
  for(i = 0; i < NUM_FOUNDABLE; i++){
    cout << i + 1 << "." << m_allFoundables[i].GetName() << "| " << m_allFoundables[i].GetType() << "| " << m_allFoundables[i].GetRarity() << "| " << m_allFoundables[i].GetToughness() << endl;
  }
}

void Game::WizardStat(){

  cout << "Information about Wizard " << m_wizard.GetName() << endl;
  cout << "Level: " << m_wizard.GetLevel() << endl;
  cout << "Toughness: " << m_wizard.GetToughness() << endl;
  cout << "Foundables found: " << m_wizard.GetLevel() - 1 << endl;
  cout << "Wins: " << m_wizard.GetWins() << " Losses: " << m_wizard.GetLosses() << endl;
  //ensures that the wizard percentage is a shown as a decimal number
  cout.setf(ios::fixed);
  cout.setf(ios::showpoint);
  cout.precision(2);
  if(m_wizard.GetLevel() == 1)
    cout << "Win Rate: 0" << endl;
  else
    cout << "Win Rate: " << static_cast<double> (m_wizard.GetWins()) / (m_wizard.GetWins() + m_wizard.GetLosses()) << endl;
  cout << noshowpoint;

}

void Game::PrintMyFoundables(){
  
  m_wizard.PrintMyFoundables();
}

void Game::AttackFoundable(){

  int i;
  int j;
  int k;
  int rarityChoice;
  int counter;
  int rarityCounter;
  int rarityStore;

  cout << "What rarity of foundable would you like to challenge (1-5)? " << endl;
  cin >> rarityChoice;
  while(rarityChoice > 5 || rarityChoice < 1){
    cout << "Must choose a rarity between 1 and 5." << endl;
    cout << "What rarity of foundable would you like to challenge (1-5)? " << endl;
    cin >> rarityChoice;
  }

  //counts all of the foundables that have the chosen rarity in the array
  //holding all of the foundables
  for(j = 0; j < NUM_FOUNDABLE; j++){
    if(m_allFoundables[j].GetRarity() == rarityChoice)
      rarityCounter++;
  }
  //counts all of the foundables that have the chosen rarity in the array
  //holding the defeated foundables
  for(k = 0; k < NUM_FOUNDABLE; k++){
    if(m_wizard.CheckFoundable(m_allFoundables[k]) == true)
      if(m_allFoundables[k].GetRarity() == rarityChoice)
	counter++;
  }
  rarityStore = rarityChoice;
  //makes sure that the user attacks a foundable of a different rarity
  //if all foundables of the chosen rarity have already been defeated
  while(counter == rarityCounter && rarityStore == rarityChoice){
    //tells the user if all foundables of a certain rarity ahve been found
    cout << "All foundables of rarity " << rarityChoice << " have been found." << endl;
    cout << "Choose a different rarity: " << endl;
    cin >> rarityChoice;
    while(rarityChoice > 5 || rarityChoice < 1){
      cout << "Must choose a rarity from 1 to 5." << endl;
      cout << "What rarity would you like to choose" << endl;
      cin >> rarityChoice;
    }
  }

  //sets i to be a random number in the foundables array
  i = rand() % NUM_FOUNDABLE;
  //searhces for a random foundable in the array that has the rarity that the
  //user has chosen
  while(m_allFoundables[i].GetRarity() != rarityChoice || m_wizard.CheckFoundable(m_allFoundables[i]) == true){
    i = rand() % NUM_FOUNDABLE;
  }
    cout << "The wizard " << m_wizard.GetName() << " " << "attacks " << m_allFoundables[i].GetName() << endl;
    //if the wizard defeats the foundable, add it to the array of foundables
    //that the wizard has defeated
    if(m_wizard.AttackFoundable(m_allFoundables[i]) == true){
      m_wizard.InsertFoundable(m_allFoundables[i]);
    }

}
  
Game::Game(){

  cout << "Welcome to Harry Potter: Wizards Unite" << endl;
  cout << "192 Foundables loaded" << endl;
  LoadFoundables();
  GetWizardName();
  MainMenu();
}
