#include "Node.h"

//Getters
Node* Node::GetNext(){
  return m_next;
}

bool Node::GetValue(){
  return m_value;
}

//Setter for next node in linked list
void Node::SetNext(Node* next){
  m_next = next;
}

void Node::ReplaceValue(){
  //Replaces node with 0 if it is a 1 and 1 if it is a zero
  if(m_value == true)
    m_value = false;
  else if(m_value == false)
    m_value = true;
}

//Default Constructor
Node::Node(){}

//Destructor
Node::~Node(){}

//Contructor  
Node::Node(bool value){
  
  m_value = value;
  m_next = nullptr;

}
