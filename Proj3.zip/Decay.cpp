#include "Decay.h"

void Decay::EmptyLists(){

  for(int i = 0; i < (int)m_list.size(); i++){
    delete m_list.at(i);
  }
}

void Decay::LoadFile(){

  //use char because it skips whitespace
  char line;
  ifstream inputStream;
  DecayList* newList = new DecayList();
  Node* item;
  cout << "What is the name of the file? " << endl;
  cin >> m_file;
  inputStream.open(m_file);
  //read in the whole file
  while(inputStream >> line){
    //until you hit the semicolon, add the numbers to the linked list
    if(line != ';'){
      if(line == '0'){
	item = new Node(false);
	newList->InsertEnd(item);
      }
      if(line == '1'){
	item = new Node(true);
	newList->InsertEnd(item);
      }
    }
    //once you hit a semicolon, add the list to the vector
    if(line == ';'){
      m_list.push_back(newList);
      newList = new DecayList();
    }
  }
  delete newList;
  inputStream.close();
}

void Decay::ChooseList(){

  int size = m_list.size();
  int listChoice;
  cout << "Which Decay scenario do you want to experience?" << endl;
  //prints out all of the lists and how many nodes are in each
  for(int i = 0; i < size; i++){
    cout << i + 1 << "." << " List " << i + 1 << "(" << m_list.at(i)->GetSize() << " nodes)" << endl;
  }
  cin >> listChoice;
  //input validation
  while(listChoice < 1 || listChoice > size){
    cout << "You must choose an option between 1 and " << size << endl;
    cout << "Which Decay scenario do you want to experience?" << endl;
    for(int i = 0; i < size; i++){
      cout << i + 1 << "." << " List " << i + 1 << "(" << m_list.at(i)->GetSize() << " nodes)" << endl;
      cin >> listChoice;
    }
  }
  //runs the simulation on the list choice
  RunSimulation(listChoice - 1);
}

void Decay::CreateRandomList(){

  int listSize;
  DecayList* newList = new DecayList();
  Node* item;
  int randVal;
  cout << "How large a list would you like?" << endl;
  cin >> listSize;
  //input validation
  while(listSize < 1 || listSize > 10000){
    cout << "Must be a list of size 1-10000" << endl;
    cout << "how large a list would you like? " << endl;
    cin >> listSize;
  }
  //randomly adds either a 1 or a 0 until the random list is full
  //to the size that the user has chosen
  for(int i = 0; i < listSize * 3; i++){
    randVal = rand() % 2 + 1;
    if(randVal == 2){
      item = new Node(true);
      newList->InsertEnd(item);
    }
    if(randVal == 1){
      item = new Node(false);
      newList->InsertEnd(item);
    }
  }
  //add the list to the vector
  m_list.push_back(newList);
  //run the simulation on the random list
  RunSimulation(0);
}

void Decay::RunSimulation(int index){

  int removeChoice;
  //lets the user pick what they want to remove until the list is
  //completely deleted
  while(m_list.at(index)->GetSize() >= NUM_CONSECUTIVE){
    m_list.at(index)->PrintDecayList();
    cout << "Which node to change? " << endl;
    cin >> removeChoice;
    while(removeChoice < 1 || removeChoice > m_list.at(index)->GetSize()){
      cout << "Number must be between 1 and " << m_list.at(index)->GetSize() << endl;
      cout << "Which node to change? " << endl;
      m_list.at(index)->PrintDecayList();
      cin >> removeChoice;
    }
    //inverts the value and then checks to see if any 1s can be removed
    m_list.at(index)->InvertValue(removeChoice);
    m_list.at(index)->TraverseList();
  }
  cout << "You have removed all of the nodes!" << endl;
}

void Decay::Start(){

  int choice = 0;
  int counter = 0;
  //dsiplays the main menu
  cout << "Welcome to Decay, where you code a frustrating system instead of doing your physics homework." << endl;
  cout << "1. Load File" << endl;
  cout << "2. Simulate Loaded File" << endl;
  cout << "3. Simulate Random List" << endl;
  cout << "4. Quit" << endl;
  cin >> choice;
  //input validation
  while(choice > 4 || choice < 1){
    cout << "You must choose an option between 1 and 4." << endl;
    cout << "1. Load File" << endl;
    cout << "2. Simulate Loaded File" << endl;
    cout << "3. Simulate Random List" << endl;
    cout << "4. Quit" << endl;
    cin >> choice;
  }
  //call LoadFile() if they pick 1
  if(choice == 1){
    counter ++;
    LoadFile();
    cout << "Welcome to Decay, where you code a frustrating system instead of doing your physics homework." << endl;
    cout << "1. Load File" << endl;
    cout << "2. Simulate Loaded File" << endl;
    cout << "3. Simulate Random List" << endl;
    cout << "4. Quit" << endl;
    cin >> choice;
    //input validation
    while(choice > 4 || choice < 1){
      cout << "You must choose an option between 1 and 4." << endl;
      cout << "1. Load File" << endl;
      cout << "2. Simulate Loaded File" << endl;
      cout << "3. Simulate Random List" << endl;
      cout << "4. Quit" << endl;
      cin >> choice;
    }
  }
  //makes sure you load in a file before choosing a list
  while(choice == 2 && counter == 0){
    cout << "You must load in a file before picking a list." << endl;
    cout << "Welcome to Decay, where you code a frustrating system instead of doing your physics homework." << endl;
    cout << "1. Load File" << endl;
    cout << "2. Simulate Loaded File" << endl;
    cout << "3. Simulate Random List" << endl;
    cout << "4. Quit" << endl;
    cin >> choice;
    //input validation
    while(choice > 4 || choice < 1){
      cout << "You must choose an option between 1 and 4." << endl;
      cout << "1. Load File" << endl;
      cout << "2. Simulate Loaded File" << endl;
      cout << "3. Simulate Random List" << endl;
      cout << "4. Quit" << endl;
      cin >> choice;
    }
  }
  //if they pick two, call ChooseList()
  if(choice == 2)
    ChooseList();
  //if they pick three, call CreateRandomlist()
  if(choice == 3)
    CreateRandomList();
}

//Constructor
Decay::Decay(){
  m_file = "";
}

//Desctructor
Decay::~Decay(){
  EmptyLists();
}
