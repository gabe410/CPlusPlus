#include "DecayList.h"

//Getter for size
int DecayList::GetSize(){
  return m_size;
}

void DecayList::InvertValue(int index){

  //counts until at the correct index, and then uses ReplaceValue()
  //to invert the value at the selected index
  int counter = 0;
  for(Node* curr = m_head; curr != nullptr; curr = curr->GetNext()){
    counter ++;
    if(counter == index)
      curr->ReplaceValue();
  }
}

bool DecayList::PrintDecayList(){

  //returns false if the list is empty and/or didn't print correctly
  if(m_head == nullptr)
    return false;
  //prints the list values in correct format
  for(Node* curr = m_head; curr != nullptr; curr = curr->GetNext()){
    if(curr->GetValue() == true)
      cout << "|1|->";
    if(curr->GetValue() == false)
      cout << "|0|->";
  }
  cout << "END";
  cout << endl;
  //prints the user selections
  for(int i = 0; i < m_size; i++){
    cout << " " << i + 1 << "   ";
  }
  cout << endl;

  //returns true when list is correctly printed
  return true;
}

int DecayList::TraverseList(){

  //numCards is the number of nodes being removed
  int numCards = 0;
  int trueCounter = 0;
  int listCounter = 0;
  Node* curr = m_head;

  //counts where in the list you are
  while(curr != nullptr){
    listCounter++;
    //counts how many 1s in a row there are
    if(curr->GetValue() == true){
      trueCounter++;
      //if there is 3 1s in a row, delete them at the correct index
      if(trueCounter == NUM_CONSECUTIVE){
	RemoveNodes(listCounter - trueCounter, NUM_CONSECUTIVE);
	numCards += trueCounter;
	trueCounter = 0;
      }
    }
    //if it is a zero, then reset the counter for 1s in a row
    else
      trueCounter = 0;    
    curr = curr->GetNext();
  }
  //updates size
  m_size -= numCards;
  if(m_size == 0)
    m_head = nullptr;
  cout << numCards << " nodes removed!" << endl;
  return numCards;
}

int DecayList::RemoveNodes(int index, int numNodes){

  int counter = 0;
  Node* temp = m_head;
  int deleteCounter = 0;
  Node* curr = m_head;
  Node* prev = m_head;
  //these two if statements are so that nodes don't get removed if the
  //size of the list is less than 3
  if(m_head == nullptr)
    return 0;
  if(m_head->GetNext() == nullptr || m_head->GetNext()->GetNext() == nullptr)
    return 0;
  //gets us to the right spot/index in the list
  while(counter < index){
    if(curr != m_head)
      //sets index of the previous node
      prev = prev->GetNext();
    //sets index of the current node
    curr = curr->GetNext();
    counter ++;
  }
  //removes 3 nodes
  while(deleteCounter != numNodes){
    //resets/moves m_head
    if(index == 0)
      m_head = m_head->GetNext();
    temp = curr->GetNext();
    delete curr;
    deleteCounter++;
    curr = temp;
  }
  //sets the pointer to the correct node
  prev->SetNext(curr);
  return numNodes;
}

bool DecayList::CheckEmpty(){
  //if m_head is null, then the list is empty, return true
  if(m_head == nullptr)
    return true;
  //otherwise return false
  return false;
}

void DecayList::InsertEnd(Node* temp){
  
  Node* curr = m_head;
  //inserts the first item into the linked list
  if(m_head == nullptr){
    m_head = temp;
    m_size++;
  }
  //inserts all of the other inputted items one after the other into
  //the linked list
  else {
    
    for(int i = 0; i < m_size - 1; i++){
      curr = curr->GetNext();
    }
    curr->SetNext(temp);
    m_size++;
  }
}

//Constructor
DecayList::DecayList(){
  m_head = nullptr;
  m_size = 0;
}

//Destructor
DecayList::~DecayList(){
  Node* current = m_head;
  while(current != nullptr){
    Node* next = current->GetNext();
    delete current;
    current = next;
    m_size--;
  }
  m_head = nullptr;
}
