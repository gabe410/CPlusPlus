#include "BabyDragon.h"

//Constructors
BabyDragon::BabyDragon(){}

BabyDragon::BabyDragon(string name, int hp){
  SetName(name);
  SetHealth(hp);
}

//Virtual function
int BabyDragon::SpecialAttack(){

  int attackDamage = 4;
  cout << "Baby Dragon breathes a cone of fire at you!" << endl;
  return attackDamage;

}
