#include "Monster.h"

//Constructors
Monster::Monster(){}

Monster::Monster(string name, int hp){
  SetName(name);
  SetHealth(hp);
}

int Monster::Attack(){

  int damage = 1;
  cout << GetName() << "deals 1 point of damage!" << endl;
  return damage;
  
}
