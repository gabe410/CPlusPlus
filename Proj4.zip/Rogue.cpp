#include "Rogue.h"

//Constructors
Rogue::Rogue(){}

Rogue::Rogue(string name, int hp){
  SetName(name);
  SetHealth(hp);
}

//Destructor
Rogue::~Rogue(){}

//Virtual function
int Rogue::SpecialAttack(){

  int attackDamage = rand() % 12 + 2;
  cout << GetName() << " performs a sneak attack!" << endl;
  cout << GetName() << " deals " << attackDamage << " damage!" << endl;
  return attackDamage;

}
