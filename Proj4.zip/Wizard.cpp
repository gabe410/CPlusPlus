#include "Wizard.h"

//Constructors
Wizard::Wizard(){}

Wizard::Wizard(string name, int hp){
  SetName(name);
  SetHealth(hp);
}

//Destructor
Wizard::~Wizard(){}

//Virtual function
int Wizard::SpecialAttack(){

  int attackDamage = rand() % 12 + 3;
  cout << GetName() << " casts magic missile!" << endl;
  cout << GetName() << " deals " << attackDamage << " damage!" << endl;
  return attackDamage;

}
