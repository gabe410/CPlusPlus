#include "Character.h"

//Constructors
Character::Character(){}

Character::Character(string name, int hp){
  SetName(name);
  SetHealth(hp);
}

//Destructor
Character::~Character(){}


int Character::Attack(){

  //creates a random attack damage each time it is called
  int damage;
  damage = rand() % 6 + 1;
  cout << GetName() << " attacks dealing " << damage << "." <<  endl;
  return damage;

}

int Character::SpecialAttack(){

  cout << "Character does not have a special attack" << endl;
  return 0;

}
