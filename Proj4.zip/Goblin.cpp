#include "Goblin.h"

//Constructors
Goblin::Goblin(){}

Goblin::Goblin(string name, int hp){
  SetName(name);
  SetHealth(hp);
}

//Virtual function
int Goblin::SpecialAttack(){

  int attackDamage = 2;
  cout << "Goblin knaws at your ankles!" << endl;
  return attackDamage;
}
