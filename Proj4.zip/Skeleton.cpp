#include "Skeleton.h"

//Constructors
Skeleton::Skeleton(){}

Skeleton::Skeleton(string name, int hp){
  SetName(name);
  SetHealth(hp);
}

//Virtual Function
int Skeleton::SpecialAttack(){

  int attackDamage = 1;
  cout << "Skeleton bashes you with it's own arm" << endl;
  return attackDamage;

}
