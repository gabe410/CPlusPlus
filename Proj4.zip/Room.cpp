#include "Room.h"
//Getters
string Room::GetName(){
  return m_name;
}

int Room::GetID(){
  return m_ID;
}

string Room::GetDesc(){
  return m_desc;
}

int Room::CheckDirection(char myDirection){

  //checks the direction that is being passed
  //then checks to make sure that there is an exit in that direction
  //for each direction, and if there is, it returns the ID of that direction
  if(myDirection == 'N' || myDirection == 'n'){
    if(m_direction[0] > -1)
      return m_direction[0];
    else
      return -1;
  }
  if(myDirection == 'E' || myDirection == 'e'){
    if(m_direction[1] > -1)
      return m_direction[1];
    else
      return -1;
  }
  if(myDirection == 'S' || myDirection == 's'){
    if(m_direction[2] > -1)
      return m_direction[2];
    else
      return -1;
  }
  if(myDirection == 'W' || myDirection == 'w'){
    if(m_direction[3] > -1)
      return m_direction[3];
    else
      return -1;
  }
  return -1;
}

void Room::PrintRoom(){

  //checks the value at each index and prints the directions out accordingly
  cout << "You are in " << m_name << ". " << m_desc << endl;
  cout << "Possible Exits: ";
  for(int i = 0; i < 4; i++){
    if(m_direction[i] != -1){
      if(i == 0)
	cout << "N ";
      if(i == 1)
        cout << "E ";
      if(i == 2)
        cout << "S ";
      if(i == 3)
        cout << "W ";
    }
  }
  cout << endl;
}

//Constructor
Room::Room(int iD, string name, string description, int north, int east, int south, int west){
  m_ID = iD;
  m_name = name;
  m_desc = description;
  m_direction[0] = north;
  m_direction[1] = east;
  m_direction[2] = south;
  m_direction[3] = west;
}
