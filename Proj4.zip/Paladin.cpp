#include "Paladin.h"

//Constructors
Paladin::Paladin(){}

Paladin::Paladin(string name, int hp){
  SetName(name);
  SetHealth(hp);
}

//Destructor
Paladin::~Paladin(){}

//Virtual function
int Paladin::SpecialAttack(){

  int attackDamage = rand() % 8 + 1;
  cout << GetName() << " uses smite evil!" << endl;
  cout << GetName() << " deals " << attackDamage << " damage!" << endl;
  return attackDamage;
}
