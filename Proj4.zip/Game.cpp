#include "Game.h"

void Game::LoadMap(string map){

  string id;
  string name;
  string desc;
  string north;
  string east;
  string south;
  string west;
  Room* room;
  ifstream inputStream;
  inputStream.open(map);

  //this loop reads in each section of the text and when it gets to the end of
  //a room it creates a new room and adds it to the vector
  while(getline(inputStream, id, '|') && getline(inputStream, name, '|') && getline(inputStream, desc, '|') && getline(inputStream, north, '|') && getline(inputStream, east, '|') && getline(inputStream, south, '|') && getline(inputStream, west, '|')){  
    room = new Room(stoi(id), name, desc, stoi(north), stoi(east), stoi(south), stoi(west));
    m_myMap.push_back(room);
  }
  inputStream.close();
}

void Game::CharacterCreation(){

  string charName;
  int charChoice = 0;
  cout << "Character Name: " << endl;
  cin >> charName;
  cout << "Select a class" << endl;
  cout << "1. Rogue" << endl;
  cout << "2. Wizard" << endl;
  cout << "3. Paladin" << endl;
  cout << "4. No class" << endl;
  cin >> charChoice;
  //input validation
  while(charChoice > 4 || charChoice < 1){
    cout << "Must be a choice between 1 and 4." << endl;
    cout << "Select a class" << endl;
    cout << "1. Rogue" << endl;
    cout << "2. Wizard" << endl;
    cout << "3. Paladin" << endl;
    cout << "4. No class" << endl;
    cin >> charChoice;
  }
  //depending on what the user chooses, it creates a character
  if(charChoice == 1)
    m_myCharacter = new Rogue(charName, ROGUE_HEALTH);
  if(charChoice == 2)
    m_myCharacter = new Wizard(charName, WIZARD_HEALTH);
  if(charChoice == 3)
    m_myCharacter = new Paladin(charName, PALADIN_HEALTH);
  if(charChoice == 4){
    m_myCharacter = new Character(charName, 10);
    m_numSpecial = 0;
  }
}

void Game::StartGame(){

  m_numRests = NUM_RESTS;
  m_numSpecial = NUM_SPECIAL;
  CharacterCreation();
  m_curRoom = START_ROOM;
  Action();

}

void Game::Action(){

  int choice = 0;
  char lookChoice;

  cout << "Welcome to UMBC Adventure!" << endl;
  m_myMap.at(m_curRoom)->PrintRoom();
  //sets the monster to null so that it can be checked to see if a user
  //has defeated a monster or left the room without attacking it
  m_curMonster = nullptr;

  //runs the game until either the character dies or the user quits
  while(choice != 6 && m_myCharacter->GetHealth() > 0){
    cout << endl;
    cout << "What would you like to do? " << endl;
    cout << "1. Look" << endl;
    cout << "2. Move" << endl;
    cout << "3. Attack" << endl;
    cout << "4. Rest" << endl;
    cout << "5. Check Stats" << endl;
    cout << "6. Quit" << endl;
    cin >> choice;
    //input validation
    while(choice > 6 || choice < 1){
      cout << "Must pick an option 1-6." << endl;
      cout << "What would you like to do? " << endl;
      cout << "1. Look" << endl;
      cout << "2. Move" << endl;
      cout << "3. Attack" << endl;
      cout << "4. Rest" << endl;
      cout << "5. Check Stats" << endl;
      cout << "6. Quit" << endl;
      cin >> choice;
    }
    if(choice == 1){
      cout << "Which direction would you like to look? (N E S W)" << endl;
      cin >> lookChoice;
      //checks the direction the user chooses and prints the room if it is
      //there otherwise it tells the user that there is no exit
      if(m_myMap.at(m_curRoom)->CheckDirection(lookChoice) == -1)
	cout << "There is nothing here. This is not an exit" << endl;
      else
	m_myMap.at(m_myMap.at(m_curRoom)->CheckDirection(lookChoice))->PrintRoom();
    }
    if(choice == 2){
      //checks to see if user has fleed a room with a monster
      //and if they have, it deletes the monster
      if(m_curMonster != nullptr){
	delete m_curMonster;
	m_curMonster = nullptr;
      }
      //lets the user move
      Move();
      //prints the new room
      m_myMap.at(m_curRoom)->PrintRoom();
      if(m_curRoom == 0)
	cout << "It is peaceful here." << endl;
      else
	//populates the rooms with monsters (or not)
	RandomMonster();
    }
    if(choice == 3){
      //lets the user attack if there is a monster in the room
      if(m_curRoom == 0 || m_curMonster == nullptr)
	cout << "You cannot attack if there is no monster in the room" << endl;
      else
	Attack();
    }
    if(choice == 4){
      //makes sure that the user has rests, and if they do, it restores their
      //health and special attacks
      if(m_numRests <= 0)
	cout << "You are out of rests!" << endl;
      else {
	cout << m_myCharacter->GetName() << " rests and gains more health and special attacks are refreshed!" << endl;
	m_numRests -= 1;
	m_myCharacter->SetHealth(m_myCharacter->GetHealth() + REST_HEAL);
	m_numSpecial = NUM_SPECIAL;
      }
    }
    if(choice == 5)
      Stats();
  }
}

Entity* Game::RandomMonster(){

  //uses a random number between 1-4 to create a random monster or no monster
  int random;
  random = rand() % 4 + 1;
  //based off of the random number, it will create a monster (or not)
  if(random == 1){
    m_curMonster = new Goblin("Goblin", GOBLIN_HEALTH);
    cout << "A goblin is here picking his nose" << endl;
  }
  if(random == 2){
    m_curMonster = new BabyDragon("Baby Dragon", DRAGON_HEALTH);
    cout << "A baby dragon is here breathing fire" << endl;
  }
  if(random == 3){
    m_curMonster = new Skeleton("Skeleton", SKELETON_HEALTH);
    cout << "A skeleton lumbers around the room" << endl;
  }
  if(random == 4){
    m_curMonster = nullptr;
    cout << "It is peaceful here" << endl;
  }
  return m_curMonster;
}

void Game::Move(){

  char move;
  cout << "Which direction? (N E S W)" << endl;
  cin >> move;
  //makes sure the user doesn't move outside of the map
  while(m_myMap.at(m_curRoom)->CheckDirection(move) == -1){
    cout << "There are no exits in this direction." << endl;
    cout << "Which direction? (N E S W)" << endl;
    cin >> move;
  }
  //sets the new current room to the direction of move that the user has chosen
  m_curRoom = m_myMap.at(m_curRoom)->CheckDirection(move);
}

void Game::Attack(){

  int attackChoice;
  //special probability is the 25% chance that a monster uses a special attack
  int specialProbability;
  specialProbability = rand() % 4 + 1;
  //this loop lets the character and the monster fight until one of them dies
  while(m_curMonster->GetHealth() > 0 && m_myCharacter->GetHealth() > 0){
     cout << m_myCharacter->GetName() << "'s Health: " << m_myCharacter->GetHealth() << endl;
      cout << m_curMonster->GetName() << "'s Health: " << m_curMonster->GetHealth() << endl;
      cout << "1. Normal Attack" << endl;
      cout << "2. Special Attack" << endl;
      cin >> attackChoice;

      //input validation
      while(attackChoice > 2 || attackChoice < 1){
	cout << "Must choose between 1)Normal Attack or 2)Special Attack" << endl;
	cout << "1. Normal Attack" << endl;
	cout << "2. Special Attack" << endl;
      }
      //makes sure user doesn't use a special attack if they are out of them
      while(attackChoice == 2 && m_numSpecial == 0){
	cout << "You are out of special attacks" << endl;
	cout << "1. Normal Attack" << endl;
	cout << "2. Special Attack" << endl;
	cin >> attackChoice;
      } 
      if(attackChoice == 1){

	//sets the new health of the monster after the character's attack
	m_curMonster->SetHealth(m_curMonster->GetHealth() - m_myCharacter->Attack());
	if(specialProbability == 1)
	  //sets the new health of the character after the monster's attack
	  m_myCharacter->SetHealth(m_myCharacter->GetHealth() - m_curMonster->SpecialAttack());
	else
	  m_myCharacter->SetHealth(m_myCharacter->GetHealth() - m_curMonster->Attack());
      }

      if(attackChoice == 2){

	m_curMonster->SetHealth(m_curMonster->GetHealth() - m_myCharacter->SpecialAttack());
	if(specialProbability == 1)
	  m_myCharacter->SetHealth(m_myCharacter->GetHealth() - m_curMonster->SpecialAttack());
	else
	  m_myCharacter->SetHealth(m_myCharacter->GetHealth() - m_curMonster->Attack());
	m_numSpecial--;
      }
   }
  //deletes the monster if it is killed
  if(m_curMonster->GetHealth() <= 0){
     cout << "You have defeated the " << m_curMonster->GetName() << endl;
     delete m_curMonster;
     m_curMonster = nullptr;
  }
  if(m_myCharacter->GetHealth() <= 0)
    cout << "You have died! Game Over." << endl;
}

void Game::Stats(){

  cout << "Name: " << m_myCharacter->GetName() << endl;
  cout << "HP: " << m_myCharacter->GetHealth() << endl;
  cout << "Rests: " << m_numRests << endl;
  cout << "Special: " << m_numSpecial << endl; 

}

//Constructors
Game::Game(){}

Game::Game(string game){

  LoadMap(game);
  StartGame();
  m_numRests = NUM_RESTS;
  m_numSpecial = NUM_SPECIAL;

}

//Destructor
Game::~Game(){

  for(int i = 0; i < (int)m_myMap.size(); i++){
    delete m_myMap.at(i);
  }
  delete m_myCharacter;
  delete m_curMonster;
}
