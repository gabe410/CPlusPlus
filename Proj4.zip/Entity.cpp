#include "Entity.h"

string Entity::GetName(){
  return m_name;
}

int Entity::GetHealth(){
  return m_health;
}

void Entity::SetName(string name){
  m_name = name;
}

void Entity::SetHealth(int hp){
  m_health = hp;
}

ostream& operator<<(ostream& out, Entity& thing){

  out <<  thing.GetName() << " " << thing.GetHealth() << endl;
  return out;
  
}

Entity::Entity(){}

Entity::Entity(string name, int hp){
  m_name = name;
  m_health = hp;
  m_level = 0;
}

Entity::~Entity(){}
